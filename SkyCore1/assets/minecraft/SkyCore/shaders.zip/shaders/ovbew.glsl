#version 120

uniform sampler2D texture;
uniform vec2 texelSize;
uniform vec3 color;
uniform vec3 color2;
uniform float time;

uniform float speed;
uniform float scale;
uniform float outline;
uniform float glow;
uniform float fill;
uniform float alpha;

#define TAU 6.28318530718
#define MAX_ITER 5

float getEdge(vec2 uv, float s) {
    float a0 = texture2D(texture, uv).a;
    float ax1 = texture2D(texture, uv + vec2(texelSize.x * s, 0.0)).a;
    float ax2 = texture2D(texture, uv - vec2(texelSize.x * s, 0.0)).a;
    float ay1 = texture2D(texture, uv + vec2(0.0, texelSize.y * s)).a;
    float ay2 = texture2D(texture, uv - vec2(0.0, texelSize.y * s)).a;
    float edge = abs(a0 - ax1) + abs(a0 - ax2) + abs(a0 - ay1) + abs(a0 - ay2);

    float axd1 = texture2D(texture, uv + vec2(texelSize.x * s, texelSize.y * s)).a;
    float axd2 = texture2D(texture, uv + vec2(-texelSize.x * s, texelSize.y * s)).a;
    float axd3 = texture2D(texture, uv + vec2(texelSize.x * s, -texelSize.y * s)).a;
    float axd4 = texture2D(texture, uv + vec2(-texelSize.x * s, -texelSize.y * s)).a;
    edge += 0.75 * (abs(a0 - axd1) + abs(a0 - axd2) + abs(a0 - axd3) + abs(a0 - axd4));

    return clamp(edge * 2.25, 0.0, 1.0);
}

void main() {
    vec2 uvMain = gl_TexCoord[0].st;
    float m = texture2D(texture, uvMain).a;

    if (m <= 0.0) discard;

    float t = time * speed + 23.0;
    // Scale UVs based on settings
    vec2 uv = uvMain * scale;

    vec2 p = mod(uv * TAU, TAU) - 250.0;
    vec2 i = vec2(p);
    float c = 1.0;
    float inten = 0.005;

    for (int n = 0; n < MAX_ITER; n++) {
        float t_iter = t * (1.0 - (3.5 / float(n + 1)));
        i = p + vec2(cos(t_iter - i.x) + sin(t_iter + i.y), sin(t_iter - i.y) + cos(t_iter + i.x));
        c += 1.0 / length(vec2(p.x / (sin(i.x + t_iter) / inten), p.y / (cos(i.y + t_iter) / inten)));
    }

    c /= float(MAX_ITER);
    c = 1.17 - pow(c, 1.4);

    float pattern = clamp(pow(abs(c), 8.0), 0.0, 1.0);

    vec3 finalRGB = mix(color, color2, pattern);

    float edge = getEdge(uvMain, outline);
    float edgeGlow = pow(edge, 0.55) * glow;

    vec3 outputColor = finalRGB * (fill * m + edgeGlow * 0.5);

    float outA = clamp(alpha * (0.2 + edge * 1.1 + pattern * 0.4 + edgeGlow * 0.3), 0.0, 1.0);

    gl_FragColor = vec4(outputColor, outA * m);
}